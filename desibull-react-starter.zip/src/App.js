import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome to Desibull Chat Room</h1>
      <p>Chat app coming soon with love!</p>
    </div>
  );
}

export default App;
